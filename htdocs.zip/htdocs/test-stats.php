<?php
require_once 'config/database.php';

$data = $pdo->getData();
$stats = $data['stats'];

// Compter les abonnés approuvés
$approvedCount = 0;
foreach($data['subscribers'] as $sub) {
    if($sub['status'] == 'approved' && $sub['is_blocked'] != 1) {
        $approvedCount++;
    }
}

echo "<h1>Test statistiques</h1>";
echo "<p>Visiteurs: " . ($stats['visitors_count'] ?? 0) . "</p>";
echo "<p>Abonnés approuvés: " . $approvedCount . "</p>";
echo "<p>Sermons MEGA: " . ($stats['sermons_count_mega_manual'] ?? 0) . "</p>";
echo "<p>Sermons DEGOO: " . ($stats['sermons_count_degoo_manual'] ?? 0) . "</p>";
echo "<hr>";
echo "<h2>Liste des abonnés:</h2>";
foreach($data['subscribers'] as $sub) {
    echo "- " . $sub['first_name'] . " " . $sub['last_name'] . " (" . $sub['email'] . ") - Statut: " . $sub['status'] . " - Bloqué: " . ($sub['is_blocked'] ? 'Oui' : 'Non') . "<br>";
}
?>